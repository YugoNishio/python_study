#繰り返し処理(for)とリスト
"""
for 目標変数 in 繰り返しの範囲:
   繰り返す内容
"""

#例
words = ['Japanese', 'English', 'French']
for word in words: #変数wordに0～2番目までの配列の中身が入る
    print(word)

#繰り返し処理(for)とrange()
#単に10回繰り返す

for num in range(5): #変数numに0～4までの値が入る
    print(num)

#range関数の使い方について(for_2.pyに続く…)