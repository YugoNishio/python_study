#forの二重ループによる行・列の生成

for i in range(3):
    for j in range(5):
        print(i, j) #2変数以上の出力の表記