#数値を入力して計算させたい。

num = input("数値を入力してください(int)") #numという変数に入力された文字を格納
int_num = int(num) #文字列をint型に変換
print(2*int_num) #int型の数値を倍にして出力

float_num = float(input("数値を入力してください(float)")) #numという変数に入力された文字を格納,文字列をfloat型に変換
print(2*float_num) #float型の数値を倍にして出力

#他にpythonが出来ることは?(input_print_3.pyに続く…)