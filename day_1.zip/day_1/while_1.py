#while文の基本
"""
while 条件式：
   条件式がTrueの時の実行内容
"""

#例
con = 0 #初期化
while con < 5: #ループ条件
    print(con)
    con += 1
print("終了")

#whileの終了時に実行する(while_2.pyに続く…)