class Car:
    def __init__(self, [引数]):
        #インスタンス変数の初期化
    def car_info(self):
        #出力コード

#オブジェクト/インスタンス生成
#メソッドの呼び出し